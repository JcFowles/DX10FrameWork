#include "BaseMesh.h"


CBaseMesh::CBaseMesh()
{
}


CBaseMesh::~CBaseMesh()
{
}

//void CBaseMesh::Draw(UINT _vertexLayoutID, UINT _techniqueID)
//{
	//this->Draw( _vertexLayoutID,  _techniqueID);
	// Render the Object
//	m_pRenderer->RenderObject(m_staticBufferID, _vertexLayoutID, _techniqueID);
//}